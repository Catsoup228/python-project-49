import random

def random_num():
    return random.randrange(0, 100)
