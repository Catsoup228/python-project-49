from brain_games1.games import even
from brain_games1.index import game_logic


def main():
    game_logic(even)


if __name__ == '__main__':
    main()
