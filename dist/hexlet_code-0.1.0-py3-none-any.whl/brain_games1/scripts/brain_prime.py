from brain_games1.games import prime
from brain_games1.index import game_logic


def main():
    game_logic(prime)


if __name__ == '__main__':
    main()
