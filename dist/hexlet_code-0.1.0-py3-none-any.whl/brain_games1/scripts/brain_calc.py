from brain_games1.games import calc
from brain_games1.index import game_logic

def main():
    game_logic(calc)

if __name__ == '__main__':
    main()