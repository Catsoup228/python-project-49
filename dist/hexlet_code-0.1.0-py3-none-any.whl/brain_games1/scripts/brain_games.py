#!/usr/bin/env python3

from brain_games1.cli import welcome_user


def main():
    welcome_user()

main()
