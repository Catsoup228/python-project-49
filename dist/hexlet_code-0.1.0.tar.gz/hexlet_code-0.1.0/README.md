### Hexlet tests and linter status:
[![Actions Status](https://github.com/Catsoup228/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Catsoup228/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/9c4d11941600062b103f/maintainability)](https://codeclimate.com/github/Catsoup228/python-project-49/maintainability)


Игра 1: проверка на четность
[![asciicast](https://asciinema.org/a/LLyl4h9jQ3waYd9kYuJ0v4cuG.svg)](https://asciinema.org/a/LLyl4h9jQ3waYd9kYuJ0v4cuG) 

Игра 2: калькулятор 
[![asciicast](https://asciinema.org/a/sk9rAhVszUwjyjc383p7J8dqp.svg)](https://asciinema.org/a/sk9rAhVszUwjyjc383p7J8dqp)

Игра 3: наибольший общий делитель 
[![asciicast](https://asciinema.org/a/S4odnO5Ek0H0PvEABIwM9Djf3.svg)](https://asciinema.org/a/S4odnO5Ek0H0PvEABIwM9Djf3)

Игра 4: прогрессия 
[![asciicast](https://asciinema.org/a/UWMcqRZ3xJfd7GwUktrfxkayE.svg)](https://asciinema.org/a/UWMcqRZ3xJfd7GwUktrfxkayE)

Игра 5: простое число
[![asciicast](https://asciinema.org/a/ROfr79c7f5IHWmS6BZpBbCBJQ.svg)](https://asciinema.org/a/ROfr79c7f5IHWmS6BZpBbCBJQ)