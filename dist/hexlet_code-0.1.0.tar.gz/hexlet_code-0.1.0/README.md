### Hexlet tests and linter status:
[![Actions Status](https://github.com/Catsoup228/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Catsoup228/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/9c4d11941600062b103f/maintainability)](https://codeclimate.com/github/Catsoup228/python-project-49/maintainability)