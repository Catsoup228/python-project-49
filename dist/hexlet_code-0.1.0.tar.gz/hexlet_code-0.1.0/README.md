### Hexlet tests and linter status:
[![Actions Status](https://github.com/Catsoup228/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Catsoup228/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/9c4d11941600062b103f/maintainability)](https://codeclimate.com/github/Catsoup228/python-project-49/maintainability)


Игра 1: проверка на четность 
    пример: https://asciinema.org/a/LLyl4h9jQ3waYd9kYuJ0v4cuG