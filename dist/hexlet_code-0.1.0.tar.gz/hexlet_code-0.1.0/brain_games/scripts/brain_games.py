def greet(text):
    print(text)

def main():
    greet('Welcome to the Brain Games!')