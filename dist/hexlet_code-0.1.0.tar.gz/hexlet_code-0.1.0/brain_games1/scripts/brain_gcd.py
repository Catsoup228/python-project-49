from brain_games1.games import gcd
from brain_games1.index import game_logic


def main():
    game_logic(gcd)


if __name__ == '__main__':
    main()
